package com.shojabon.man10gachav3.enums;

/**
 * Created by sho on 2018/07/14.
 */
public enum GachaPaymentType {
    VAULT,
    ITEM,
    ITEM_BANK
}
